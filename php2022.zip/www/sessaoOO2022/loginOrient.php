<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title> Acessar sistema de alunos </title>
</head>
<body>
	<h3> Pagina de login - Orientadores </h3>
   <form action="valueOrient.php" method="post">
   	  <p> Usuário:	<input type="text" name="usuario"> 
   	  <p> Senha:  <input type="password" name="senha">
   	  <input type="hidden" name="orient">
   	  <p> <button type="submit"> Acessar </button>
   </form>
</body>
</html>
