<?php 

include_once("classes/Sessao.php"); // para ter acesso ao método estático logoff()

  if (isset($_GET['logoff'])){
    Sessao::logoff(); 
    // para criar menos arquivos, chamo o método estático que quebra a sesão
}
    session_start();
  if(isset($_SESSION['login'])) {
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Formulario de cadastro de ex alunos </title>
</head>
  <body>
        <h3> Pagina de cadastro - Ex alunos </h3>
        <form action="addAluno.php" method="post">
          <p>
            Digite o nome: 
            <input type="text" name="nome">
          </p>  

          <p>
            Digite uma Senha: 
            <input type="password" name="pass">
          </p>  
          
          <p>
            Digite o seu E-mail: 
            <input type="email" name="email">
          </p>
          
          <p>
            <button type="submit"> Cadastrar </button>
          </p>

        </form>

      <a href="?logoff">Sair</a> <!-- aqui no href estou passando um valor via get para a prória página -->

  </body>
</html>

<?php 
  } // fecha o bloco do if 
  else{
    
    echo "Você não tem acesso autorizado! <br>";
    
    echo "<a href='loginOrient.php'> Voltar à página de login </a>";
  }
?>