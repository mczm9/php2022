<?php 

	include_once("classes/Crud.php");

	extract($_POST); // substitui o metodo abaixo, isso para todos os que teriam que criar.

	//$usuario = $_POST['usuario'];
/*	
	echo $user. "<br>";
	echo $pass. "<br>";		// TESTE SE ESTA RECEBENDO
	echo $email. "<br>";
*/	
	// Criptografar user e pass
	$user = password_hash("$user", PASSWORD_DEFAULT);
	$pass = password_hash("$pass", PASSWORD_DEFAULT);

/*
	echo $user, "<br>".$pass; // TESTE SE ESTA GERANDO O HASH CERTINHO
*/
	$obj = new Crud();

	$res = $obj->insertDados($user,$pass,$email);

		if ($res = true) {
			
			echo "Cadastro realizado com sucesso!"."<br>";
			echo "<a href='formCadUser.php'> Voltar à página de cadastro </a>"; // EU QUE COLOQUEI
		}
 ?>