<?php 

	include_once("Conexao.php");


	class Crud extends Conexao {

		private $stmt;
		
			public function insertDados($user,$pass,$email){

		$this->stmt = $this->Conect()->prepare("INSERT INTO usuarios(nome,senha,email) VALUES(:use,:chave,:mail)");

		return $this->stmt->execute(array(":use"=>$user,":chave"=>$pass,":mail"=>$email)); // INSERIR VALORES NOS CAMPOS DO BANCO

		}

	}


 ?>