<?php 

include_once("classes/Sessao.php"); // importa a classe Sessao

    $orientador = $_POST['usuario']; // validação do usuário do formulário 
    $password = $_POST['senha'];  // validação da senha do formulário
    $contole = $_POST['orient'];

    $obj = new Sessao; // cria objeto da classe Sessao

    $dados = $obj->readOrient(); // chama método da classe Sessão que consulta os usuários do BD

    // var_dump($dados); // Verificar se está sendo passado tudo certo

foreach($dados as $usuario => $valores){ // Login para mais de um usuário.
    
    if(password_verify($orientador,$valores->nome) && password_verify($password,$valores->senha)){

        Sessao::autorizado($contole); // usa o método estático para escrever menos linha de código
        break;
    
    } else{
        $loginNot = true; // se a autenticação falhar, não achar usuários e senhas 
    }   
}

if($loginNot){
    echo "Usuário não encontrado, tente novamente! <br>";
    echo "<a href='loginOrient.php'> Voltar à página de login </a>";
}

?>