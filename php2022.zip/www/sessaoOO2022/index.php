<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title> Acessar sistema de cadastro </title>
</head>
<body>
	<h3> Pagina de login - Direção </h3>
   <form action="valida.php" method="post">
   	  <p> Usuário:	<input type="text" name="usuario"> 
   	  <p> Senha:  <input type="password" name="senha">
   	  <p> <button type="submit"> Acessar </button>
   </form>
</body>
</html>

