<?php 

// hash -> é uma criptografia

echo " Código User: ".password_hash("Suporte", PASSWORD_DEFAULT);  // gerar hash para o usuário estabelecido

echo "<br> Código Pass: ".password_hash("admAfl22", PASSWORD_DEFAULT);  // gerar hash da senha estabelecida para o usuário



// Apagar arquivo/ retirar da pasta do site quando os hashes forem gerados, para no site não ficar com o usuario e a senha expostos 







?>