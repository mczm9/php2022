<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Cadastro PHP </title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<style type="text/css">
	body{
		background-image: url(https://i.pinimg.com/564x/f9/20/69/f920698ca19b918b61be0f6c45f0b319.jpg);
	}
</style>
<body>
<header> <h2> Formulário Cadastro </h2></header>
<section>
	<div class="container">
	<form>
		<button type="submit" class="btn btn-primary">aperte aqui</button>
	</form>	
	</div>
</section>
<footer>
		itachi lindo - 2022
</footer>
<script src="bootstrap/js/bootstrap.bundle.min.js">
</script>
</body>
</html>