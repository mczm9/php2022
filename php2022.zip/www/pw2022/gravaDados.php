<style type="text/css"> /*posso usar css sem precisar abrir o html*/
li{
	color: black;
	font-size: large;
	text-decoration: none; /*retira o sublinhado*/
	list-style: none; /*retira o pontinho que vai na lista*/
	font-family:fantasy ;
}	
</style>
<?php 

$filhosPessoa = $_GET['filhos'];
$bonusPessoa = $_GET['bonus'];

echo "<li> $filhosPessoa </li> <li> $bonusPessoa </li>";
?>