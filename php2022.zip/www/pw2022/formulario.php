<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Formulário </title>
	<style type="text/css">
		body{
			background-image: url(https://pbs.twimg.com/media/Et5M7nMWQAklhoh.jpg);
			background-size: 100% 190%;
			background-repeat: no-repeat;
		}
	</style>
</head>
<body>
<form method="post" action="valida.php">
	<p> Funcionário: <input type="text" name="funcionario"></p>
	<p> Salário: <input type="number" name="salario"></p>
	<p> Filhos: <input type="radio" name="filhos" value="sim"> Sim</p>
	            <input type="radio" name="filhos" value="não"> Não</p>
	<p> Cursos Proficionalizantes: </p>
	<p> Eletricista <input type="checkbox" name="eletric"> </p>
	<p> Animador <input type="checkbox" name="animador"> </p>
	<p> Engenheiro <input type="checkbox" name="engenheiro"> </p>
	<p> Frentista <input type="checkbox" name="frentista"> </p>
	<p> Informática <input type="checkbox" name="inf"> </p>
    
    <p> Qual o seu sexo? 
         F <input type="checkbox" name="f">
         M <input type="checkbox" name="m">
    </p>

	<p> <button type="submit"> Gravar Dados </button></p>
</form>
</body>
</html>