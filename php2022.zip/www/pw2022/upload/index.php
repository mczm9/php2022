<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Criação de diretórios e upload de arquivos </title>
</head>
<style type="text/css">
	body{
		background-image: url(https://i.pinimg.com/originals/e3/df/45/e3df450493b5941b1d77da704a2e6a29.gif);
		background-repeat: no-repeat;
		background-size: 100% 600%;
	}
</style>
<body>
	<h2> Sistema de upload de arquivos </h2>
  <form enctype="multipart/form-data" action="upload.php" method="POST">
    <p> Nome do diretório: 
    	<input type="text" name="diretorio">
    </p>
    <p> Nome do aluno: 
    	<input type="text" name="aluno">
    </p>
    <p> <input type="file" name="userfile"> </p> <!-- carregar o arquivo -->
    <p> <button type="submit"> Enviar arquivo </button> </p>

  </form>
</body>
</html>
<?php  
echo "string";
?>