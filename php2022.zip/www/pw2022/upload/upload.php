 <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Upload </title>
	<style type="text/css">
	body{
		background-image: url(https://i.pinimg.com/564x/62/1f/ee/621feefba8183acdce327f99360f0418.jpg);
		background-repeat: no-repeat;
		background-size: 100% 400%;
	}
</style>
</head>
<body>

</body>
</html> 
<?php
var_dump($_FILES['userfile']); //pegar arquivo($files) 
 
echo $_FILES['userfile']['name'];

$size = $_FILES['userfile']['size'];

$error = $_FILES['userfile']['error'];

echo "<br>".$size;
echo "<br>".$error;

$dir = $_POST['diretorio'];

if (is_dir($dir)) { //verifica se ha um diretorio com esse nome(is dir)
	// code...
}else{
	mkdir($dir); //cria o diretorio
}
$nomeF = $_FILES['userfile']['name'];
$nomeTemp = $_FILES['userfile']['tmp_name'];
$nomeAluno = $_POST['aluno'];

$parInfo = pathinfo("$nomeF");

$ext = $parInfo['extension'];

$ctr = move_uploaded_file($nomeTemp,$dir."/".$nomeAluno.".$ext"); 
//colocar o nome do aluno sem perder a extensão do arquivo

// $ctr = move_uploaded_file($nomeTemp,$dir."/".$nomeFile);


if ($ctr) {
	echo "Upload realizado!!";
}else{
	echo "Upload foi interrompido por erro";
}
?>