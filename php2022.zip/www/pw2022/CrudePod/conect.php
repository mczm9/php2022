<?php 

$bank = "crudePhp2022";
$host = "127.0.0.1";
$user_bd = "root";
$pass_bd = ""



 ?>