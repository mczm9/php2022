<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Página de Links </title>
</head>
<style type="text/css">
body{
	background-image: url(https://c.tenor.com/FRfu1lHGgrUAAAAM/itachi-uchiha-naruto.gif);
	background-size: cover;
}	
a{
	font-family:monospace ;
	font-size: 30px;
}
</style>
<body>

<nav> <!-- conjunto de links, é usado a tag nav -->
<ul>
<li> <!-- lista não numerada -->
<a href="http://localhost/pw2022/getUrl.php?idade=16&salario=1700">
	Página com informaçãoes do Funcionário
</a>

<ul>
<li>
<a href="gravaDados.php?filhos=3&bonus=500">
	Registrar informações do Funcionário
</a>
</li>
</ul>	
</li>	
</ul>	
</nav>
</body>
</html>