<!-- variavel superglobal do tipo Array p enviar dados de fomularios enão fica no url = POST -->
<!-- esse formulario não precisa chamar outra página para mostrar as informações obtidas -->


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Validar Formulário na mesma Página </title>
	<style type="text/css">
		body{
			background-image: url(https://i.pinimg.com/564x/1c/5e/e2/1c5ee28371dd22dd6f7493310ded55b3.jpg);
			background-repeat: no-repeat;
			background-size: 100% 2500%;
		}
	</style>
</head>
<body>
<form method="post">
	Nome: <input type="text" name="nome">
	Idadde : <input type="number" name="idade">
	<button type="submit" name="sub"> Validar </button> <!-- para enviar as informações no metodo post eu só posso usar o submit no php, e button no javascript -->
</form>
<?php 
 if(isset($_POST['sub'])){
   // $nome = $_POST['nome'];
   // $idade = $_POST['idade']; essa é uma forma mais extensa de validar os campos

   // extract($_POST); //extrai o valor da variável evem com o conteudo que o usuario digitar e serve quando já temos muitas lonhas de código

   // echo $nome." - ".$idade;

 	// var_dump($_POST); 

 	$post['nome'] = "Mcz";
 	$post['idade'] = "16";

 	var_dump($post);

 }
 ?>

 <input type="text" name="nome" value="<?=$nome;?>"> <!-- sintaxe curta para imprimir algum valor p escrever -->

</body>
</html>