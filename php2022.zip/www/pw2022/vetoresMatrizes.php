<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Array e Matriz</title>
    <style type="text/css">
   td{
    text-align: center;
    background-color: aquamarine;
    background-image: url();
   } 
</style>
</head>
<body>
</body>
</html>
<?php 
$estagio = array("Manutenção","Design","Programação","Serviços de Informática");
                   // 0        1            2               3


echo $estagio[3]."<br>";

echo $estagio[0]."<br>"; //leitura dos dados manual

$size = count($estagio); //tamanho do vetor

for($i = 0; $i < $size; $i++){
    echo "index:".$i." - ".$estagio[$i]."<br>";
} 

echo "<hr>";

$areaEstagio = array(
	0 => "Manutenção",
	1 => "Design",
	2 => "Programação",
	3 => "Serviços de Informática"
   );

echo $areaEstagio[1]."<br>";



foreach ($areaEstagio as $value) { //percorre os vetores automaticamente e sequencial em matrizes(com a key atribui o valor e não somente o vetor)
    echo $value."<br>";
}

echo "<hr>";

foreach ($areaEstagio as $index => $value){
    echo "index : $index | valor: $value.<br>";
    }
echo "<hr>";

$novoVetor = array(); //vetor vazio

$novoVetor[0] = 10; //novo valor do vetor tira colchete do 10 e coloca na leitura do for fornece todos os valores e não somente o ultimo

for ($i=0; $i < 20 ; $i++) { //add valores com vetor no for
   $novoVetor[] = $i;
}

var_dump($novoVetor);

echo "<hr>";

// array associativo EM VEZ DA CHAVE EU TENHO O NOME
$dadosClientes = array(
"Nome" => "Maria Clara",
"CPF" => "087883456-18",
"RG" => "2006089107117",
"idade" => 55, 
"altura" => 1.75
);

echo $dadosClientes['CPF']."<br>";
echo $dadosClientes['RG']."<br>";

foreach ($dadosClientes as $value) { //sem a chave pega apenas os valores
    echo "$value <br>";
}

echo "<hr>";

foreach ($dadosClientes as $key => $value) { //chaves e valores
    echo "Chave : $key | Valor : $value <br>";
}

echo "<br>";

echo "<table boder=1>"; //tabela
foreach ($dadosClientes as $key => $value) { //Tabela
    echo "<tr><td> $key </td><td> $value</td></tr>";
}

echo "</table>";

echo "<hr>";

//Array multidimensionais e matrizes (vetor é chave e valor, já matriz é uma tabela com categorais e informacoes sobre essas categorias, guardando elas em células, a matriz é como se fosse uma array dentro de outro)

$clientes = array(
        "José" => array("idade"=>25,"CPF"=>"087883456-18","RG"=>"2006089107117"), //nivel01= jose nivel02=inf de jose
        "Maria" => array("idade"=>18,"CPF"=>"057825456-15","RG"=>"2001089097112"),
        "Ana" => array("idade"=>24,"CPF"=>"037825445-30","RG"=>"2019089097118") 
    );



echo $clientes["José"]["RG"]."<br>"; //pega uma informacao como se fosse 
echo $clientes["Ana"]["idade"]; 

var_dump($clientes); //visualizar a estrutura da matriz como no código

echo "<hr>";
foreach ($clientes as $nivel01 => $nivel02) {
    echo $nivel01."<br>";

  foreach ($nivel02 as $key => $value) {
       echo $key.":".$value."<br>";
    }
}

echo "<table boder=1>";
foreach ($clientes as $nivel01 => $nivel02) {
    echo "<tr><td colspan='2'> $nivel01 </td> </tr>";

  foreach ($nivel02 as $key => $value) {
      echo "<tr> <td> $key </td> <td> $value </td> </tr>";
  }
  }
  echo "</table>";

  echo "<hr>";

  //    Crie uma matriz que possa agrupar informações sobre os 3 cursos da escola, organize esses dados de modo a destacar, nome dos cursos das turmas de cada curso e o numero alunos de cada turma 
//1º forma de resolver
  $turmas = array(
        "Admin" => array("1º"=> 41, "2º"=> 35, "3º"=> 38),
        "Informática" => array("1º"=> 41, "2º"=> 35, "3º"=> 30),
        "Enfermagem" => array("1º"=> 41, "2º"=> 39, "3º"=> 33),
    );

  echo $turmas["Informática"]["3º"]."<br>";

  //2º forma de resolver
  $turmas = array(
"Admin" => array("1º"=> array("qnt"=> 40),
                 "2º"=> array("qnt"=> 41),
                 "3º"=> array("qnt"=> 30),
),
"Info" => array("1º"=> array("qnt"=> 40),
                 "2º"=> array("qnt"=> 41),
                 "3º"=> array("qnt"=> 33),
),
"Enf" => array("1º"=> array("qnt"=> 42),
                 "2º"=> array("qnt"=> 41),
                 "3º"=> array("qnt"=> 32),
   )
);

echo $turmas["Admin"]["2º"]["qnt"]."<br>";
echo "<hr>";

foreach ($turmas["Admin"] as $anos => $info) {
    echo $anos."<br>";

    foreach ($info as $key => $value) {
       echo $key.":".$value."<br>";
    }
}
echo "<hr>";
foreach ($turmas as $cursos => $info) {
    echo $cursos."<br>";
    foreach ($info as $turmas => $alunos) {
    echo $turmas."<br>";
    foreach ($alunos as $key => $qnt) {
    echo $key.":".$qnt."<br>";
}
}
}
// $clientes = array(
//   0 => array(0 => 3, 1 =>5, 2 =>8),
//   1=> array(8, true, false),
//   2 => array(5,9,10)
//     );

echo "Eu passei aqui huehuehuehue";
?>