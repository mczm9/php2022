<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Lendo Arquivo </title>
</head>
<style type="text/css">
	body{
		background-color: #35154d;
	}
</style>
<body>

</body>
</html>

<?php 
$dados = file("dados.txt");

//var_dump($dados); //mostra a estrutura e informações do vetor

$size = count($dados);

for ($i=0; $i < $size ; $i++) { 
	echo $dados[$i]."<br>";
}
 ?>