<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Página Inicial </title>
</head>
<body>
<?php

$nome = "Clara";
$idade = 16;
$salario = 1212.7;
?>
<table border="1"> <!-- sintaxe curta -->
	<tr> <th>Funcionária</th> <th>Idade</th> <th>Remuneração</th></tr>
	<tr> <td><?=$nome ?></td>
         <td><?=$idade ?></td>
         <td><?=$salario ?></td>
	</tr>
</table>

<table border="1"> <!-- sintaxe mais longa -->
<tr> <th>Funcionária</th> <th>Idade</th> <th>Remuneração</th></tr>
<tr> <td><?php echo $nome ?></td>
     <td><?php echo $idade ?></td>
     <td><?php echo $salario ?></td>
	</tr>
</table>
</body>
</body>
</html>