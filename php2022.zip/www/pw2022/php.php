<?php


echo "Progamação Web";

echo "<br>"; //quebra de linha

print("EEEP Amélia");

echo "<hr>"; 

$salario = 1212.7;

$idade = 16;

$nome = "Clara";
// echo "<br>";
// echo $nome; imprime apenas o nome
echo "Funcionária: ".$nome; //junta o que está entre o parentese e o conteúdo da tag que usa o "." para contatenar
echo "<br>";
echo "Idade: ".$idade;
echo "<br>";
echo "Remuneração: ".$salario;
echo "<br>";
echo "<hr>"; 
echo "<img href='link'><img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQcfEtsm2DefEDqGkSG-c6rsIlwucZoc8iTvg&usqp=CAU'/>";


echo "<table border='1'>";
echo "<tr> <th>Funcionária</th>  <th>Idade</th>  <th>Remineração</th> </tr>";
echo "<tr> <td> $nome </td> <td> $idade </td> <td> $salario </td> </tr>";
echo "</table>";

echo "<hr>";

echo "<table border='1'> 
<tr> <th>Funcionária</th> <th>Idade<th> <th>Remuneração<th> </tr>
<tr> <td> $nome </td> <td> $idade </td> <td> $salario </td> </tr>
</table>";
echo "<tr>";
echo "</table>";
?>

<!-- comando echo para reconhecer o valor de uma variavel precida de aspas duplas e não simples -->