<?php
echo "<center><h2> Método de requisição GET </h2></center>";

$idadePessoa = $_GET['idade'];
$salarioPessoa = $_GET['salario'];  //metodo superglobal do php, coloquei no navegador idade=16 e depois autorizei a  recolhida do valor que estava no navegador para o código

echo $idadePessoa;
echo "<br>";
echo $salarioPessoa;




?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Método de requisição GET</title>
</head>
<style type="text/css">
	body{
		background-image: url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMO64ZPbXgrB1lTi3_rqm7zprFTn_A93FAUeyrJ5otzqoHLvSx1tq9Qei9tFhRIrUtkkM&usqp=CAU);
		background-repeat: no-repeat;
		background-size: 100% 100%;
	}
</style>
<body>

</body>
</html>