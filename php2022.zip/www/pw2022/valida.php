<?php 
$nome = $_POST['funcionario'];
$salario = $_POST['salario'];
$filhos = $_POST['filhos'];


echo "funcionário: ".$nome;
echo "<br>";
echo "Valor do salário: ".$salario;
echo "<br>";
echo "Tem filhos? ".$filhos;
echo "<br>";
if(isset($_POST['eletric'])){ //isset serve para retornar verdadeiro ou falso
    echo "Fez curso de Eletricista";
} 


$cursos = ""; //concatenar as strings



echo "<br>";
if(isset($_POST['animador'])){ 
    $cursos .= "Fez curso de Animador <br>";
}

if(isset($_POST['eletric'])){ 
    $cursos .= "Fez curso de Eletricista <br>";
}
if(isset($_POST['engenheiro'])){ 
    $cursos .= "engenheiro <br>";
}
if(isset($_POST['frentista'])){ 
    $cursos .= "Fez curso de frentista <br>";
}
if(isset($_POST['inf'])){ //isset serve para retornar verdadeiro ou se alguem selecionou algo ou clicou, já o if poe retornar como verdadeiro ou falso
    $cursos .= "Fez curso de inf"; //poderia usar o echo ao inves de cursos
}

// echo $cursos;
// echo "$nome - $salario - $filhos"; outra forma de validar os dados


//  if(empty($_POST['F'])) { //faz o inverso issent
//      echo "Campo não marcado";
// }
//  if(empty($_POST['M'])) { 
//      echo "Campo não marcado";
// }



echo "Funcionário: ".$nome."<br> Salário: ".$salario."<br> Filhos:" .$filhos."
<br> Cursos : <br>".$cursos;


echo "<hr>";


echo "Funcionário:$nome <br>
Salário:$salario <br>
Filhos: $filhos <br>
Cursos: <br> $cursos";
 ?>