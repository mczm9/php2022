<?php 
extract($_POST);

echo $aluno."<br>";
echo $nota;

$dado = $aluno."\r\n".$nota."\r\n"; //quebra de linha

$refFile = fopen("dados.txt", "a+");

fwrite($refFile, $dado);

fclose($refFile);
 ?>