<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Gravar dados em Arquivos </title>
	<style type="text/css">
		body{
			background-image:url(https://i.pinimg.com/originals/85/94/89/859489e9974d33b61b151abec574b912.gif) ;
			background-repeat: no-repeat;
			background-size: cover;
		}
	</style>
</head>
<body>
<form method="post" action="writeData.php">
	<p> Aluno: <input type="text" name="aluno"></p>
    <p> Nota: <input type="number" name="nota"></p>
    <button type="submit"> Enviar </button>
</form>
</body>
</html>