<!DOCTYPE html>
<html>

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Faça Login </title>

</head>

	<body>
		<form action="acesso.php" method="post">
		
			<p> Usuário: <input type="text" name="user"></p>
			<p> Senha: <input type="password" name="pass"></p>
				<button type="submit"> Acessar </button>


		</form>
	</body>

</html>