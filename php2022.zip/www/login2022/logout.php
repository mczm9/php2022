<?php 

	session_start();  // Para mecher com as sessões tem que iniciala

	session_destroy(); // Quebrar a sessão

	header("location:index.php"); // Voltar para a página inicial

exit();				// Não necessário, mas - Garantir que o código php deixe de ser executado



 ?>