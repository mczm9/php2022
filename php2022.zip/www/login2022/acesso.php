<?php 

// Receber usuário e senha dos campos de formulário.
    $userForm = $_POST['user'];
    $passForm = $_POST['pass'];

// Código para conectar o php da conexão com este do acesso.
    include_once("conexao.php");    

// Estrutura usada para reconhecer caso ouver erros.
        try{                                       
        
        $stmt = $conn->prepare("SELECT * FROM usuarios");
        $stmt-> execute();

        $result = $stmt-> fetch(PDO::FETCH_ASSOC); // Buscar cada linha no banco de dados; necessita do while ou foreach;

        $userBd = $result['user'];
        $passBd = $result['pass'];

    //echo $userForm." - ".$passForm." - ".$userBd." - ".$passBd;    Ver se ele estáva recebendo os valores.
    
            if(password_verify($userForm, $userBd) && password_verify($passForm, $passBd)){
                session_start();

                $_SESSION['usuario'] = $userForm;

                header("location:protegida.php");               // Código que linka para outra página após o login.
            } else{

                echo "Usuário ou senha incorretos!";           // Caso usário ou senha incorretos.

                // Pus extra - Lucas não pediu
                echo "<br> <a href= 'index.php'> Retomar </a>"; 
            
            }

// Estrutura catch, que trabalha junto com o try, é quem nos mostra o erro se ele existir.
        } catch(Exception $e){                 
            echo "Erro: ".$e->getMessage();      
        


        }


 ?>