<?php 
	
	session_start();
/*
	if(empty($_SESSION['usuario'])) { //isset - quando inserido; empty - se existir.
		
		header("location:index.php"); 	// fazer com que o usuário volte para o inicio - caso não tenha usuário.

	}
*/
	if(isset($_SESSION['usuario'])) {

?>


<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Página Restrita </title>

</head>

	<body>
		
		<div> Logado como: <?php echo$_SESSION['usuario']; ?></div>
		<h2> Acesso somente para pessoas autorizadas! </h2>
		<p> <a href="logout.php"> Sair </a> </p>

	</body>

</html>

<?php 

	} else {

		echo "Acesso não autorizado!";

		echo "<a href= 'index.php'> Tentar Novamente </a>";
	}

?>